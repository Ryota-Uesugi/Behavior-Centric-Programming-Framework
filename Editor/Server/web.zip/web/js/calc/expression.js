//expression.js

// ============================================================
// ドロップ時の処理
// ============================================================

window.updatecompomentArea = function(group) {
    window.processDropAndOpenUI(group, COMPONENT_CONFIG);
};

window.updateExpressionArea = function(group) {
    window.processDropAndOpenUI(group, SEND_CONFIG);
};

// ============================================================
// クリック時の処理
// ============================================================

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================================
    // Component Area
    // ============================================================
    if (window.setupGenericClickEvent) {
        window.setupGenericClickEvent('compoment-area', async function() {
            
            // 1. 最新リストを取得
            const mode = COMPONENT_CONFIG.mode; // "definition"
            let currentList = await fetchSavedcomponents(mode);

            // リスト表示関数
            const showModal = () => {
                if (window.openGenericListModal) {
                    window.openGenericListModal({
                        ...COMPONENT_CONFIG,
                        dataList: currentList,
                        
                        onDelete: async function(index) {
                            if (!confirm("本当に削除しますか？")) return;

                            const success = await deleteSavedComponent(mode, index);

                            if (success) {
                                currentList.splice(index, 1);
                                showModal();
                            }
                        }
                    });
                }
            };
            showModal();
        });
    }

    // ============================================================
    // Send Area:
    // ============================================================
    if (window.setupGenericClickEvent) {
        window.setupGenericClickEvent('expression-area', async function() {
            // 1. 最新リストを取得
            const mode = SEND_CONFIG.mode; // "expression"
            let currentList = await fetchSavedcomponents(mode);

            // リスト表示関数
            const showModal = () => {
                if (window.openGenericListModal) {
                    window.openGenericListModal({
                        ...SEND_CONFIG,
                        dataList: currentList,
                        
                        onDelete: async function(index) {
                            if (!confirm("本当に削除しますか？")) return;

                            const success = await deleteSavedComponent(mode, index);

                            if (success) {
                                currentList.splice(index, 1);
                                showModal();
                            }
                        }
                    });
                }
            };
            showModal();
        });
    }
});