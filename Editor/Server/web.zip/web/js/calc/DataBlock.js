//DataBlock.js

async function openTelemetryConfigForm(block) {
    const data = await fetchTelemetryFields();
    
    // Background (Overlay)
    const modalDiv = document.createElement('div');
    modalDiv.className = 'modal'; 

    // Content container
    const content = document.createElement('div');
    content.className = 'modal-content';
    content.style.width = '350px'; 

    // Header
    const header = document.createElement('div');
    header.className = 'modal-header';
    header.innerHTML = '<h3>Select Telemetry Field</h3>';

    // Body
    const body = document.createElement('div');
    body.className = 'modal-body';

    const msgLabel = document.createElement('p');
    msgLabel.className = 'label';
    msgLabel.textContent = 'Select Message:';
    const msgSelect = document.createElement('select');
    
    const fieldLabel = document.createElement('p');
    fieldLabel.className = 'label';
    fieldLabel.textContent = 'Select Field:';
    const fieldSelect = document.createElement('select');

    // Populate Data
    Object.keys(data).forEach(msg => msgSelect.add(new Option(msg, msg)));

    msgSelect.addEventListener('change', () => {
        fieldSelect.innerHTML = '';
        (data[msgSelect.value] || [])
            .filter(f => f !== '_ts' && f !== 'mavpackettype')
            .forEach(f => fieldSelect.add(new Option(f, f)));
    });
    msgSelect.dispatchEvent(new Event('change'));

    // Footer
    const footer = document.createElement('div');
    footer.className = 'modal-footer';

    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn-close';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.onclick = () => {
        removeBlock(block);
        modalDiv.remove();
    }

    const okBtn = document.createElement('button');
    okBtn.className = 'btn-send';
    okBtn.textContent = 'Apply';
    okBtn.onclick = () => {
        block.dataset.message = msgSelect.value;
        block.dataset.field = fieldSelect.value;
        block.dataset.configured = 'true';
        block.textContent = `${msgSelect.value}.${fieldSelect.value}`;
        
        // Use function from block.js
        if(typeof blockGroups !== 'undefined') {
            const group = blockGroups.get(block);
            if (group) {
                updateGroupBox(group);
                updateAllGroupBoxes();
            }
        }
        modalDiv.remove();
    };

    body.append(msgLabel, msgSelect, fieldLabel, fieldSelect);
    footer.append(cancelBtn, okBtn);
    content.append(header, body, footer);
    modalDiv.appendChild(content);
    document.body.appendChild(modalDiv);
}

/* ================= components Loader ================= */

async function openLoadcomponentForm(block) {
    const components = await fetchSavedcomponents();

    // UI作成
    const modalDiv = document.createElement('div');
    modalDiv.className = 'modal';

    const content = document.createElement('div');
    content.className = 'modal-content';
    content.style.width = '450px';

    const header = document.createElement('div');
    header.className = 'modal-header';
    header.innerHTML = '<h3>Load component</h3>';

    const body = document.createElement('div');
    body.className = 'modal-body';

    const footer = document.createElement('div');
    footer.className = 'modal-footer';

    const labelSelect = document.createElement('p');
    labelSelect.className = 'label';
    labelSelect.textContent = 'Select a saved component:';
    
    const componentSelect = document.createElement('select');
    componentSelect.style.width = '100%';
    componentSelect.style.marginBottom = '10px';

    const labelPreview = document.createElement('p');
    labelPreview.className = 'label';
    labelPreview.textContent = 'Expression Preview (Editable if Custom):';

    const previewTx = document.createElement('textarea');
    previewTx.readOnly = true;
    previewTx.style.width = '100%';
    previewTx.style.height = '80px';
    previewTx.style.backgroundColor = '#f0f0f0';

    // --- ボタン作成 ---
    const cancelBtn = document.createElement('button');
    cancelBtn.className = 'btn-close';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.onclick = () => {
        removeBlock(block);
        modalDiv.remove();
    };

    // Setボタン
    const setBtn = document.createElement('button');
    setBtn.className = 'btn-send';
    setBtn.textContent = 'Set'; 
    
    // Getボタン
    const getBtn = document.createElement('button');
    getBtn.className = 'btn-send';
    getBtn.textContent = 'Get';
    getBtn.style.backgroundColor = '#4CAF50'; 

    // Createボタン
    const createBtn = document.createElement('button');
    createBtn.className = 'btn-send';
    createBtn.textContent = 'Create';

    // --- データの充填 ---
    if (components.length === 0) {
        const opt = new Option("-- No saved components --", "");
        opt.disabled = true;
        componentSelect.add(opt);
    } else {
        components.forEach(item => {
            const opt = new Option(item.name, item.name);
            componentSelect.add(opt);
        });
    }
    componentSelect.add(new Option("Custom", "CUSTOM"));

    // --- Helper: コンポーネント検索 ---
    const getSelectedComponentData = () => {
        const selectedName = componentSelect.value;
        if (selectedName === 'CUSTOM') return null;
        return components.find(c => c.name === selectedName);
    };

    // --- プレビューとボタン表示の制御 ---
    const updatePreview = () => {
        const isCustom = componentSelect.value === 'CUSTOM';
        
        const compData = getSelectedComponentData();
        const type = isCustom ? null : (compData ? (compData.type || compData.classification) : null);
        
        const expression = isCustom 
            ? previewTx.value 
            : (compData ? (compData.expression || compData.definition) : "");

        // ボタン制御
        if (isCustom) {
            setBtn.style.display = 'none';
            getBtn.style.display = 'none';
            createBtn.style.display = 'inline-block';
        } else {
            createBtn.style.display = 'inline-block';

            if (type === RESULT_TYPE_VARIABLE) {
                setBtn.textContent = 'Set';
                setBtn.style.display = 'inline-block';
                getBtn.style.display = 'inline-block';
            } else if (type === RESULT_TYPE_CALCULATED) {
                // Calculated: inputがある場合のみSetを表示
                const inputCount = (compData && typeof compData.input_count === 'number') ? compData.input_count : 0;
                
                if (inputCount > 0) {
                    setBtn.textContent = 'Set';
                    setBtn.style.display = 'inline-block';
                } else {
                    setBtn.style.display = 'none';
                }
                getBtn.style.display = 'inline-block';

            } else if (type === RESULT_TYPE_FUNCTION) {
                setBtn.textContent = 'Call';
                setBtn.style.display = 'inline-block';
                getBtn.style.display = 'none';
            } else if (type === RESULT_TYPE_EXPRESSION) {
                setBtn.style.display = 'none';
                getBtn.style.display = 'none';
            } else {
                setBtn.textContent = 'Call';
                setBtn.style.display = 'inline-block';
                getBtn.style.display = 'none';
            }
        }

        // プレビュー表示制御
        if (isCustom) {
            previewTx.readOnly = false;
            previewTx.style.backgroundColor = '#ffffff';
            previewTx.placeholder = "Enter your expression here...";
            if (!previewTx.dataset.isUserTyping) previewTx.value = ""; 
        } else {
            previewTx.readOnly = true;
            previewTx.style.backgroundColor = '#f0f0f0';
            previewTx.placeholder = "";
            previewTx.dataset.isUserTyping = ""; 
            previewTx.value = expression;
        }
    };

    componentSelect.addEventListener('change', updatePreview);
    previewTx.addEventListener('input', () => {
        if (componentSelect.value === 'CUSTOM') previewTx.dataset.isUserTyping = "true";
    });

    if (componentSelect.options[0].disabled && componentSelect.options.length > 1) {
        componentSelect.selectedIndex = 1;
    }
    updatePreview();

    // --- ★Helper: スロット(inputs)生成ロジック ---
    const parseInputs = (inputCount) => {
        const count = (typeof inputCount === 'number') ? inputCount : 0;
        const inputs = [];
        for (let i = 0; i < count; i++) {
            inputs.push(`input${i + 1}`);
        }
        return inputs;
    };

    // --- ボタンアクション ---

    // 1. Set (Call) ボタン
    setBtn.onclick = () => {
        const selectedName = componentSelect.value;
        const compData = getSelectedComponentData();
        
        if (!compData) return;

        // 数値を取得
        const inputCount = (typeof compData.input_count === 'number') ? compData.input_count : 0;
        const type = compData.type || compData.classification;

        let inputs;

        // ★修正: classificationが 'variable' であっても、input_count があればそちらを優先する
        if (inputCount > 0) {
            inputs = parseInputs(inputCount);
        } else if (type === RESULT_TYPE_VARIABLE) {
            // input_countが無い(0)場合で、かつ Variable の場合のみ代入用の 'val' にする
            inputs = ['val'];
        } else {
            inputs = [];
        }

        createCallBlock(block, selectedName, inputs); 
        modalDiv.remove();
    };

    // 2. Get ボタン
    getBtn.onclick = () => {
        const selectedName = componentSelect.value;
        createGetBlock(block, selectedName);
        modalDiv.remove();
    };

    // 3. Create ボタン
    createBtn.onclick = () => {
        const selectedValue = componentSelect.value;
        const compData = getSelectedComponentData();
        let expression = "";

        if (selectedValue === 'CUSTOM') {
            expression = previewTx.value;
            if (!expression.trim()) return alert("Please enter an expression.");
        } else {
            if (!compData) return;
            expression = compData.expression || compData.definition;
        }

        try {
            const success = replaceBlockWithExpression(block, expression);
            if (success) modalDiv.remove();
        } catch (e) {
            console.error(e);
            alert(e.message);
        }
    };

    body.append(labelSelect, componentSelect, labelPreview, previewTx);
    footer.append(cancelBtn, setBtn, getBtn, createBtn);
    content.append(header, body, footer);
    modalDiv.appendChild(content);
    document.body.appendChild(modalDiv);
}

// Set用ブロック生成
function createCallBlock(targetBlock, blockName, inputsArg) {
    const newBlock = document.createElement('div');
    newBlock.className = 'block calc-func-block'; 
    newBlock.dataset.type = 'calc_func';
    newBlock.dataset.value = blockName;
    
    newBlock.style.position = "absolute";
    newBlock.style.zIndex = 1000;
    newBlock.style.display = "inline-flex";
    newBlock.style.alignItems = "center";

    const prefix = document.createElement('span');
    prefix.textContent = `${blockName}( `;
    newBlock.appendChild(prefix);

    const inputs = (Array.isArray(inputsArg) && inputsArg.length > 0) ? inputsArg : ["arg1"];

    inputs.forEach((argName, i) => {
        if (i > 0) {
            const comma = document.createElement('span');
            comma.textContent = ", ";
            newBlock.appendChild(comma);
        }
        const slot = document.createElement("div");
        slot.className = "slot";
        slot.dataset.argName = argName;
        slot.title = argName;
        if (typeof setupSlotEvents === 'function') setupSlotEvents(slot);
        newBlock.appendChild(slot);
    });

    const suffix = document.createElement('span');
    suffix.textContent = " )";
    newBlock.appendChild(suffix);

    newBlock.addEventListener("mousedown", e => {
        if (["INPUT", "SELECT", "BUTTON"].includes(e.target.tagName)) return;
        if (e.button === 0 && typeof startDrag === 'function') startDrag(e, newBlock);
    });

    placeBlockOnField(targetBlock, newBlock);
}

// Get用ブロック生成
function createGetBlock(targetBlock, blockName) {
    const newBlock = document.createElement('div');
    newBlock.className = 'block calc-func-block'; 
    newBlock.dataset.type = 'calc_func'; 
    newBlock.dataset.mode = 'get'; 
    newBlock.dataset.value = blockName;
    
    newBlock.style.position = "absolute";
    newBlock.style.zIndex = 1000;
    newBlock.style.display = "inline-flex";
    newBlock.style.alignItems = "center";
    newBlock.classList.add('block-get');

    const prefix = document.createElement('span');
    prefix.textContent = `${blockName}`;
    newBlock.appendChild(prefix);

    newBlock.addEventListener("mousedown", e => {
        if (["INPUT", "SELECT", "BUTTON"].includes(e.target.tagName)) return;
        if (e.button === 0 && typeof startDrag === 'function') startDrag(e, newBlock);
    });

    placeBlockOnField(targetBlock, newBlock);
}

function placeBlockOnField(targetBlock, newBlock) {
    if (targetBlock && targetBlock.parentNode) {
        const rect = targetBlock.getBoundingClientRect();
        const fieldRect = field.getBoundingClientRect();
        const x = rect.left - fieldRect.left + field.scrollLeft;
        const y = rect.top - fieldRect.top + field.scrollTop;

        newBlock.style.left = `${x}px`;
        newBlock.style.top = `${y}px`;
        
        field.appendChild(newBlock);

        if (typeof blocks !== 'undefined') blocks.push(newBlock);
        if (typeof blockGroups !== 'undefined') blockGroups.set(newBlock, [newBlock]);

        removeBlock(targetBlock);
    }
}


function replaceBlockWithExpression(targetBlock, expression) {
    const rect = targetBlock.getBoundingClientRect();
    const fieldRect = field.getBoundingClientRect();
    const x = rect.left - fieldRect.left + field.scrollLeft;
    const y = rect.top - fieldRect.top + field.scrollTop;

    // spawnBlocksFromExpression は既存のパース関数を想定
    const newBlock = spawnBlocksFromExpression(expression, x, y);
    
    if (newBlock) {
        // 元のブロック削除処理
        if (targetBlock.parentNode) targetBlock.parentNode.removeChild(targetBlock);
        if (typeof blocks !== 'undefined') blocks = blocks.filter(b => b !== targetBlock);
        removeBlock(targetBlock);
        return true;
    }
    return false;
}

/* ==================================================================================
   2. components Loader & Parser
   ================================================================================== */

function getOperatorType(token) {
    // 1. 既存の operators リストから検索 (優先)
    if (typeof operators !== 'undefined') {
        for (const group of operators) {
            if (group.list.includes(token) || group.list.includes(token.toLowerCase())) {
                return group.type;
            }
        }
    }

    // 2. combinableOps から型を取得
    const firstChar = token.charAt(0);
    const config = combinableOps[firstChar];

    if (config) {
        // 特例(overrides)のチェック (例: >> や <<)
        if (config.overrides && config.overrides[token]) {
            return config.overrides[token];
        }
        // 基本の型を返す (例: >=, == は condition)
        if (config.type) {
            return config.type;
        }
    }

    return null;
}

function tokenize(expression) {
    const regex = /\s*('[\s\S]*?'|=>|>=|<=|==|!=|\w+\.\w+|\d+(?:\.\d+)?|[a-zA-Z_]\w*|[+\-*/%^&|~()<>=,])\s*/g;
    let tokens = [];
    let match;
    while ((match = regex.exec(expression)) !== null) {
        if (match[0].trim()) {
            tokens.push(match[0].trim());
        }
    }
    return tokens;
}

function spawnBlocksFromExpression(expression, x, y) {
    const tokens = tokenize(expression);
    let cursor = 0;

    function peek() { return tokens[cursor]; }
    
    function consume(expected) {
        if (tokens[cursor] === expected) { cursor++; return true; }
        return false;
    }

    // ... (isOperator, finalizeArg, parseArgList は変更なし) ...
    function isOperator(t) {
        return ['>', '<', '>=', '<=', '==', '!=', '+', '-', '*', '/', '%', 'and', 'or', '&', '|', '^', '~'].includes(t)
                || (t.length === 1 && combinableOps[t] !== undefined);
    }

    function finalizeArg(slot, blocksList) {
        if (!slot || blocksList.length === 0) return;
        blocksList = blocksList.filter(b => {
            if (b.dataset.type === 'string' && b.dataset.value === '_') {
                if (b.parentNode) b.parentNode.removeChild(b);
                if (typeof blocks !== 'undefined') blocks = blocks.filter(x => x !== b);
                return false;
            }
            return true;
        });
        if (blocksList.length === 0) return;
        blocksList.forEach(b => {
            slot.appendChild(b);
            b.style.position = 'static'; 
            b.style.marginRight = '4px';
            b.style.verticalAlign = 'middle';
            b.style.display = 'inline-flex';
            b.style.justifyContent = 'center';
            b.style.alignItems = 'center';
            if (typeof blocks !== 'undefined') blocks = blocks.filter(x => x !== b);
        });
    }

    function parseArgList(slotArray) {
        let slotIndex = 0;
        let argBlocks = []; 

        while (peek() !== ')' && cursor < tokens.length) {
            let t = peek();
            
            if (t === ',') { 
                consume(','); 
                if (slotArray[slotIndex]) finalizeArg(slotArray[slotIndex], argBlocks);
                argBlocks = [];
                slotIndex++; 
                continue; 
            }
            
            let processedAsCombined = false;
            
            if (combinableOps[t] && combinableOps[t].next && cursor + 1 < tokens.length) {
                const nextToken = tokens[cursor + 1];
                if (combinableOps[t].next.includes(nextToken)) {
                    const combinedOp = t + nextToken;
                    const opType = getOperatorType(combinedOp); 
                    
                    if (opType) {
                        const opBlock = createBlock(opType, combinedOp, false, combinedOp);
                        argBlocks.push(opBlock);
                        cursor += 2;
                        processedAsCombined = true;
                    }
                }
            }

            if (processedAsCombined) continue;

            if (isOperator(t)) {
                const opType = getOperatorType(t);
                if (opType) {
                    consume(t);
                    const opBlock = createBlock(opType, t, false, t);
                    argBlocks.push(opBlock);
                } else {
                    const blk = parseBlock(); 
                    if (blk) argBlocks.push(blk);
                }
            } else {
                const blk = parseBlock(); 
                if (blk) argBlocks.push(blk);
            }
        }
        if (slotArray[slotIndex]) finalizeArg(slotArray[slotIndex], argBlocks);
    }

    // ---------------------------------------------------------
    // parseBlock
    // ---------------------------------------------------------
    function parseBlock() {
        if (cursor >= tokens.length) return null;
        
        const token = tokens[cursor];

        // 0. Inputブロック
        if (token === 'Input') {
            cursor++;
            return createBlock('input', 'Input', false);
        }

        // 1. 数値
        if (!isNaN(parseFloat(token)) && !token.startsWith("'")) {
            cursor++;
            return createBlock('number', token, false);
        }
        // 2. 文字列
        if (token.startsWith("'")) {
            cursor++;
            return createBlock('string', token.slice(1, -1), false);
        }
        // 3. Telemetry
        if (token.includes('.') && isNaN(parseFloat(token))) {
            cursor++;
            const b = createBlock('Telemetry', token, false);
            const p = token.split('.');
            b.dataset.message = p[0]; b.dataset.field = p[1]; b.dataset.configured = 'true';
            return b;
        }

        // 4. 関数 (引数の数に合わせてスロットを調整)
        if (cursor + 1 < tokens.length && tokens[cursor + 1] === '(') {
            const funcName = tokens[cursor];

            // ★A: 引数がない "Name()" の場合 → Getブロック (前回の要望対応)
            if (cursor + 2 < tokens.length && tokens[cursor + 2] === ')') {
                cursor += 3; // Name, (, ) を消費
                let category = 'calc_func';
                if (typeof FUNC_CONFIG !== 'undefined' && FUNC_CONFIG[funcName]) {
                    category = FUNC_CONFIG[funcName].category;
                }
                const getBlock = createBlock(category, funcName, false);
                getBlock.dataset.mode = 'get';
                getBlock.classList.add('block-get');
                getBlock.innerHTML = '';
                const prefix = document.createElement('span');
                prefix.textContent = funcName;
                getBlock.appendChild(prefix);
                return getBlock;
            }

            // ★B: 引数がある場合 "Name(...)" → 通常のSetブロック
            // まずカーソルを進めずに引数の数を数える
            let tempCursor = cursor + 2; // '(' の次からスタート
            let depth = 0;
            let commaCount = 0;
            // 閉じ括弧が来るまでスキャン
            while (tempCursor < tokens.length) {
                const t = tokens[tempCursor];
                if (t === '(') depth++;
                else if (t === ')') {
                    if (depth === 0) break; // 引数終了
                    depth--;
                }
                else if (t === ',' && depth === 0) {
                    commaCount++;
                }
                tempCursor++;
            }
            const argCount = commaCount + 1; // 引数の数 (カンマ数 + 1)

            // ここで正式にカーソルを進めてブロック生成
            cursor += 2; // Name, ( を消費
            
            let category = 'calc_func'; 
            if (typeof FUNC_CONFIG !== 'undefined' && FUNC_CONFIG[funcName]) {
                category = FUNC_CONFIG[funcName].category;
            }

            const funcBlock = createBlock(category, funcName, false);

            // --- ★ここから: スロット数の調整ロジック ---
            
            // Switchブロックなどの特殊系は既存ロジック(ボタン連打)に任せる
            if (funcName === 'switch') {
                if (argCount > 2) {
                    const clicksNeeded = Math.floor((argCount - 2) / 2);
                    const addBtn = funcBlock.querySelector('.btn-add-case');
                    if (addBtn) {
                        for(let k=0; k < clicksNeeded; k++) addBtn.click();
                    }
                }
            } 
            else {
                // 一般的な関数ブロック(DegreeSwitch等)の場合
                // 現在のスロット数を取得
                let currentSlots = Array.from(funcBlock.querySelectorAll('.slot'));
                
                // --- 不足している場合: スロットを追加 ---
                if (argCount > currentSlots.length) {
                    // 最後の閉じカッコ " )" や " s )" を一時退避して削除するなどの工夫が必要だが、
                    // createBlockの構造上、末尾に追加して並び替えるか、insertBeforeを使う
                    
                    // 末尾の閉じカッコテキストノードを探す(簡易的)
                    let lastTextNode = null;
                    for (let i = funcBlock.childNodes.length - 1; i >= 0; i--) {
                        if (funcBlock.childNodes[i].nodeType === Node.TEXT_ELEMENT_NODE || 
                            (funcBlock.childNodes[i].tagName === 'SPAN' && funcBlock.childNodes[i].textContent.includes(')'))) {
                            lastTextNode = funcBlock.childNodes[i];
                            break;
                        }
                    }

                    const slotsToAdd = argCount - currentSlots.length;
                    for (let i = 0; i < slotsToAdd; i++) {
                        // カンマを追加
                        const comma = document.createElement('span');
                        comma.textContent = ", ";
                        funcBlock.insertBefore(comma, lastTextNode);

                        // スロットを追加
                        const newSlot = document.createElement('div');
                        newSlot.className = 'slot';
                        newSlot.dataset.argName = `arg${currentSlots.length + i + 1}`;
                        newSlot.title = `arg${currentSlots.length + i + 1}`;
                        if (typeof setupSlotEvents === 'function') setupSlotEvents(newSlot);
                        
                        funcBlock.insertBefore(newSlot, lastTextNode);
                    }
                }
                // --- 多すぎる場合: 末尾からスロットを削除 ---
                else if (argCount < currentSlots.length) {
                    const slotsToRemove = currentSlots.length - argCount;
                    // 後ろから削除していく
                    for (let i = 0; i < slotsToRemove; i++) {
                        const slot = currentSlots[currentSlots.length - 1 - i];
                        // 直前のカンマも消したい
                        // slotの前の要素がカンマ(span)なら削除
                        const prev = slot.previousElementSibling;
                        if (prev && prev.tagName === 'SPAN' && prev.textContent.includes(',')) {
                            prev.remove();
                        }
                        slot.remove();
                    }
                }
            }
            // --- ここまで: スロット数の調整ロジック ---

            // 最新のスロットリストを取得してパース実行
            const finalSlots = Array.from(funcBlock.querySelectorAll('.slot')).filter(s => s.closest('.block') === funcBlock);
            parseArgList(finalSlots);
            
            if(!consume(')')) throw new Error(`Missing ')' for ${funcName}`);
            return funcBlock;
        }

        // 5. 演算子単体
        const opType = getOperatorType(token);
        if (opType) {
            cursor++;
            return createBlock(opType, token, false, token);
        }

        // 6. 変数名
        cursor++;
        return createBlock('string', token, false);
    }

    const rootBlock = parseBlock();
    
    if (rootBlock) {
        field.appendChild(rootBlock);
        if (typeof blocks !== 'undefined') blocks.push(rootBlock);

        rootBlock.style.position = 'absolute';
        rootBlock.style.opacity = '0';

        setTimeout(() => {
            rootBlock.style.left = `${x}px`;
            rootBlock.style.top = `${y}px`;
            rootBlock.style.opacity = '1';
            blockGroups.set(rootBlock, [rootBlock]);
        }, 10);

        return rootBlock;
    }
    return null;
}