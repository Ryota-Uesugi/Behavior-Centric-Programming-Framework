//block.js

/* ================= ユーティリティ・ヘルパー ================= */

/**
 * DOM要素生成ヘルパー
 */
const dom = {
    create: (tag, className = "", props = {}) => {
        const el = document.createElement(tag);
        if (className) el.className = className;
        Object.assign(el, props);
        return el;
    },
    input: (type, name, value, props = {}) => {
        const el = document.createElement("input");
        el.type = type;
        el.name = name;
        if (type === "checkbox") el.checked = (value === true || value === "true");
        else el.value = value || "";
        Object.assign(el, props);
        return el;
    },
    // 入力要素のイベント伝播阻止
    stopProp: (el) => {
        el.addEventListener("mousedown", (e) => e.stopPropagation());
        el.addEventListener("click", (e) => e.stopPropagation());
        return el;
    }
};

/* ================= ブロック生成ロジック (Strategy Pattern) ================= */

const BLOCK_BUILDERS = {
    // A. 演算子・条件・括弧
    simple: (block, type, value, op) => {
        block.classList.add(`${type.replace('_', '-')}-block`);
        const text = op || value;
        block.textContent = text;
        block.dataset.value = text;
    },

    // B. 数値 (Number)
    number: (block, type, value) => {
        block.classList.add("number-block");
        block.innerHTML = `<span>Number</span>`;
        
        const input = dom.input("number", "block_number_value", value || 0, { style: "width: 60px;" });
        dom.stopProp(input);
        input.addEventListener("input", (e) => { block.dataset.value = e.target.value; });
        block.appendChild(input);
    },

    // C. 文字列 (String)
    string: (block, type, value) => {
        block.classList.add("string-block");
        block.innerHTML = `<span>Text</span>`;

        const input = dom.input("text", "block_string_value", value || "text", {
            style: "width: 100px;",
            placeholder: "name"
        });
        dom.stopProp(input);
        input.addEventListener("input", (e) => { block.dataset.value = e.target.value; });
        block.appendChild(input);
    },

    // D. Bool
    bool: (block, type, value) => {
        block.classList.add("bool-block");
        Object.assign(block.style, { display: "flex", alignItems: "center", gap: "4px" });
        block.innerHTML = `<span>Bool</span>`;

        const input = dom.input("checkbox", "block_bool_value", value, { style: "cursor: pointer;" });
        dom.stopProp(input);
        input.addEventListener("change", (e) => { block.dataset.value = e.target.checked; });
        block.appendChild(input);
    },

    // E. Input / Telemetry / Component
    display: (block, type, value) => {
        if (type === "input") {
            block.classList.add("input-block");
            Object.assign(block.style, {
                display: "flex", justifyContent: "center", alignItems: "center", padding: "4px 8px"
            });
            block.textContent = value || "Input";
        } else {
            // Telemetry / component
            block.classList.add(`${type}-block`);
            block.textContent = value || type;
            block.dataset.configured = "false";
        }
    },

    // F. 関数系 / Switch
    function: (block, type, value) => {
        if (value === 'switch') {
            return setupSwitchBlock(block, value);
        }
        if (value === 'sequence') {
            return setupSequenceBlock(block, value);
        }

        const classMap = {
            'time_func': 'time-func-block',
            'export_func': 'export-func-block',
            'control_func': 'control-func-block',
            'flow_control': 'flow-control-block'
        };
        block.classList.add(classMap[type] || 'calc-func-block');
        Object.assign(block.style, { display: "inline-flex", alignItems: "center" });

        const conf = (typeof FUNC_CONFIG !== 'undefined' && FUNC_CONFIG[value]) 
                     ? FUNC_CONFIG[value] 
                     : { args: ["arg1", "arg2"] };
        
        const argList = Array.isArray(conf.args) ? conf.args : Array(conf.args).fill("arg");

        block.appendChild(dom.create('span', '', { textContent: `${value}( ` }));

        argList.forEach((argName, i) => {
            if (i > 0) block.appendChild(dom.create('span', '', { textContent: ", " }));

            const slot = dom.create("div", "slot");
            slot.dataset.argName = argName;
            slot.title = argName;

            if (type === "time_func" && i === argList.length - 1) {
                slot.dataset.accept = "number";
            }

            setupSlotEvents(slot);
            block.appendChild(slot);
        });

        const suffix = (type === "time_func") ? " s )" : " )";
        block.appendChild(dom.create('span', '', { textContent: suffix }));
    }
};

/* ================= ブロック生成コア ================= */

function createBlock(type, value = "", addToField = true, op = '', customExpr = '') {
    const block = dom.create("div", "block");
    block.dataset.type = type;
    block.dataset.value = value;
    Object.assign(block.style, { position: "absolute", zIndex: 1000 });

    // ビルダーの選択と実行
    if (["condition", "operator", "bit_operator", "parenthesis"].includes(type)) {
        BLOCK_BUILDERS.simple(block, type, value, op);
    } else if (BLOCK_BUILDERS[type]) {
        BLOCK_BUILDERS[type](block, type, value);
    } else if (["input", "Telemetry", "component"].includes(type)) {
        BLOCK_BUILDERS.display(block, type, value);
    } else if (["calc_func", "time_func", "export_func", "control_func", "flow_control"].includes(type)) {
        BLOCK_BUILDERS.function(block, type, value);
    } else {
        // Fallback or default handling if needed
        block.textContent = value || type;
    }

    // ドラッグ開始イベント
    block.addEventListener("mousedown", e => {
        if (["INPUT", "SELECT", "BUTTON", "TEXTAREA"].includes(e.target.tagName)) return;
        if (e.button === 0 && typeof startDrag === 'function') {
            startDrag(e, block);
        }
    });

    if (addToField) {
        field.appendChild(block);
        if (typeof blocks !== 'undefined') blocks.push(block);
    }
    return block;
}

/**
 * Switchブロックの内部構築ロジック
 */
function setupSwitchBlock(block, value) {
    block.classList.add('flow-control-block', 'switch-block');
    Object.assign(block.style, {
        display: "inline-flex", flexDirection: "column", alignItems: "stretch",
        padding: "6px", gap: "6px"
    });

    const conf = (typeof FUNC_CONFIG !== 'undefined' && FUNC_CONFIG[value]) 
                 ? FUNC_CONFIG[value] : { args: ["target", "case", "res", "default"] };
    const argList = Array.isArray(conf.args) ? conf.args : Array(conf.args).fill("arg");

    // --- 1. ヘッダー行 ---
    const headerRow = dom.create('div', '', { 
        style: "display: flex; align-items: center; gap: 6px; padding-left: 4px;" 
    });
    
    headerRow.appendChild(dom.create('span', '', { textContent: "Switch", style: "font-weight: bold;" }));

    const targetSlot = dom.create('div', 'slot');
    targetSlot.dataset.argName = argList[0] || "target";
    targetSlot.title = "Target Value";
    setupSlotEvents(targetSlot);
    headerRow.appendChild(targetSlot);

    const addBtn = dom.create('button', 'btn-add-case', {
        textContent: '+', title: "Add Case",
        style: "cursor: pointer; padding: 0 6px;"
    });
    addBtn.addEventListener('mousedown', (e) => e.stopPropagation());
    headerRow.appendChild(addBtn);

    block.appendChild(headerRow);

    // --- 疑似ブロック(Targetの分身)の表示更新ロジック ---
    const updateSwitchCaseVisuals = () => {
        const targetBlock = targetSlot.querySelector('.block');
        const pseudoText = targetBlock ? "Target" : null;
        
        block.querySelectorAll('.case-result-row').forEach(row => {
            const cSlot = row.querySelector('.slot[data-arg-name^="case"]');
            if (!cSlot) return;

            let pseudo = row.querySelector('.pseudo-target-block');
            
            if (pseudoText) {
                if (!pseudo) {
                    pseudo = dom.create('div', 'pseudo-target-block', {
                        style: "opacity: 0.7; font-size: 0.8em; margin-right: 2px;"
                    });
                    row.insertBefore(pseudo, cSlot);
                }
                pseudo.textContent = pseudoText;
                cSlot.style.borderTopLeftRadius = "0";
                cSlot.style.borderBottomLeftRadius = "0";
            } else {
                if (pseudo) pseudo.remove();
                cSlot.style.borderTopLeftRadius = "";
                cSlot.style.borderBottomLeftRadius = "";
            }
        });
    };

    const observer = new MutationObserver(updateSwitchCaseVisuals);
    observer.observe(targetSlot, { childList: true });

    // --- [Helper] Case行生成関数 ---
    const createCaseRow = (caseArgName, resArgName) => {
        const row = dom.create('div', 'case-result-row', {
            style: "display: flex; justify-content: flex-start; align-items: center; gap: 4px; padding-left: 4px;"
        });

        const cSlot = dom.create('div', 'slot');
        cSlot.dataset.argName = caseArgName || "case";
        cSlot.title = "Case Condition";
        setupSlotEvents(cSlot);
        row.appendChild(cSlot);

        const rSlot = dom.create('div', 'slot');
        rSlot.dataset.argName = resArgName || "result";
        rSlot.title = "Result Value";
        setupSlotEvents(rSlot);
        row.appendChild(rSlot);

        // 削除ボタン
        const delBtn = dom.create('button', 'btn-del-case', {
            textContent: '-', title: "Remove Case",
            style: "margin-left: 4px; cursor: pointer;"
        });
        delBtn.addEventListener('mousedown', (e) => e.stopPropagation());
        delBtn.onclick = () => {
            row.querySelectorAll('.block').forEach(b => removeBlock(b));
            row.remove();
            updateSwitchCaseVisuals();
        };
        row.appendChild(delBtn);

        return row;
    };

    // --- 3. デフォルト行 (Default) ---
    const defaultRow = dom.create('div', 'default-row', {
        style: "display: flex; align-items: center; gap: 4px; margin-top: 4px; padding-left: 4px;"
    });

    defaultRow.appendChild(dom.create('span', '', { textContent: "default :", style: "font-size: 0.9em;" }));

    const defSlot = dom.create('div', 'slot');
    defSlot.dataset.argName = argList[argList.length - 1] || "default";
    defSlot.title = "Default Value";
    setupSlotEvents(defSlot);
    defaultRow.appendChild(defSlot);

    block.appendChild(defaultRow);

    // --- ボタンクリック動作 ---
    addBtn.onclick = () => {
        block.insertBefore(createCaseRow("case_ext", "result_ext"), defaultRow);
        updateSwitchCaseVisuals();
    };

    setTimeout(updateSwitchCaseVisuals, 0);
}

/**
 * Sequenceブロックの内部構築ロジック
 */
function setupSequenceBlock(block, value) {
    block.classList.add('flow-control-block', 'sequence-block');
    Object.assign(block.style, {
        display: "inline-flex", flexDirection: "column", alignItems: "stretch",
        padding: "6px", gap: "4px"
    });

    // 設定取得 (デフォルトは step1, step2)
    const conf = (typeof FUNC_CONFIG !== 'undefined' && FUNC_CONFIG[value]) 
                 ? FUNC_CONFIG[value] : { args: ["step1", "step2"] };
    const argList = Array.isArray(conf.args) ? conf.args : Array(conf.args).fill("step");

    // --- 1. ヘッダー行 (+ボタン) ---
    const headerRow = dom.create('div', '', { 
        style: "display: flex; align-items: center; justify-content: space-between; gap: 6px; padding: 0 4px;" 
    });
    
    headerRow.appendChild(dom.create('span', '', { textContent: "Sequence", style: "font-weight: bold;" }));

    const addBtn = dom.create('button', 'btn-add-step', {
        textContent: '+', title: "Add Step",
        style: "cursor: pointer; padding: 0 6px;"
    });
    addBtn.addEventListener('mousedown', (e) => e.stopPropagation());
    headerRow.appendChild(addBtn);

    block.appendChild(headerRow);

    // --- [Helper] Step行生成関数 ---
    const createStepRow = (argName) => {
        const row = dom.create('div', 'sequence-step-row', {
            style: "display: flex; align-items: center; gap: 4px; padding-left: 4px;"
        });

        // 実行ステップ用スロット
        const slot = dom.create('div', 'slot');
        slot.dataset.argName = argName || "step";
        slot.title = "Execute Step";
        slot.style.minWidth = "80px"; // 少し広めに確保
        setupSlotEvents(slot);
        row.appendChild(slot);

        // 削除ボタン
        const delBtn = dom.create('button', 'btn-del-step', {
            textContent: '-', title: "Remove Step",
            style: "cursor: pointer;"
        });
        delBtn.addEventListener('mousedown', (e) => e.stopPropagation());
        delBtn.onclick = () => {
            row.querySelectorAll('.block').forEach(b => removeBlock(b));
            row.remove();
        };
        row.appendChild(delBtn);

        return row;
    };

    // --- 2. 初期引数分の行を生成 ---
    argList.forEach(argName => {
        block.appendChild(createStepRow(argName));
    });

    // --- ボタンクリック動作 ---
    addBtn.onclick = () => {
        block.appendChild(createStepRow("step_ext"));
    };
}

/* ================= スロットイベント管理 ================= */

let lastHoveredSlot = null;

function setupSlotEvents(slot) {
    slot.addEventListener('mouseenter', (e) => {
        if (!dragInfo) return;
        e.stopPropagation();

        if (lastHoveredSlot && lastHoveredSlot !== slot) {
            lastHoveredSlot.classList.remove('slot-hover-valid', 'slot-hover-invalid');
        }
        lastHoveredSlot = slot;

        const validation = (typeof validateSlotDrop === 'function') 
                           ? validateSlotDrop(dragInfo.group, slot) 
                           : { ok: true, reason: "" };

        if (validation.ok) {
            if (globalTooltip) globalTooltip.style.display = 'none';
            slot.classList.add('slot-hover-valid'); 
        } else {
            slot.classList.add('slot-hover-invalid');
            if (globalTooltip) {
                globalTooltip.textContent = `🚫 ${validation.reason}`;
                Object.assign(globalTooltip.style, {
                    display: 'block', opacity: '1',
                    left: `${slot.getBoundingClientRect().right + 10}px`,
                    top: `${slot.getBoundingClientRect().top - 10}px`
                });
            }
        }
    });

    slot.addEventListener('mouseleave', () => {
        slot.classList.remove('slot-hover-valid', 'slot-hover-invalid');
        if (lastHoveredSlot === slot) lastHoveredSlot = null;
        if (globalTooltip) globalTooltip.style.display = 'none';
    });

    slot.addEventListener('mouseup', (e) => {
        e.stopPropagation();
        if(typeof handleSlotDrop === 'function') handleSlotDrop(e, slot);
    });
}

/* ================= 複製・削除・グルーピング管理 ================= */

function duplicateBlock(original, targetX = null, targetY = null) {
    if (!original || !original.dataset) return null;
    const { type, value = "", op = "", expr = "" } = original.dataset;
    
    // 1. 標準的な複製（初期状態のブロック生成）
    const clone = createBlock(type, value, true, op, expr);
    if (!clone) return null;

    if (targetX !== null && targetY !== null) {
        clone.style.left = `${targetX}px`;
        clone.style.top = `${targetY}px`;
    }

    // ★修正2: Getブロックの複製特例処理
    // Getモードの場合、createBlock(Function型)によって作られたスロットやカッコを削除し、
    // シンプルなGetブロックの形状に戻す
    if (original.dataset.mode === 'get') {
        clone.dataset.mode = 'get';
        clone.classList.add('block-get');
        
        // createBlockで作られた中身（関数名 + スロット）をクリア
        clone.innerHTML = '';
        
        // 変数名だけを持つspanを再追加
        const prefix = document.createElement('span');
        prefix.textContent = value;
        clone.appendChild(prefix);
        
        // スロットの再帰コピーは不要なのでここで終了
        return clone;
    }

    // Input/Bool値のコピー
    const origInput = original.querySelector('input');
    const cloneInput = clone.querySelector('input');
    if (origInput && cloneInput) {
        if (type === 'bool') {
            cloneInput.checked = origInput.checked;
            clone.dataset.value = origInput.checked;
        } else {
            cloneInput.value = origInput.value;
            clone.dataset.value = origInput.value;
        }
    }

    if (type === 'Telemetry') {
        clone.dataset.configured = original.dataset.configured; 
        clone.textContent = original.textContent;
        clone.dataset.value = original.dataset.value;
    }
    
    // 単純なテキストコピー（inputブロック等）
    if (["condition", "operator", "bit_operator", "parenthesis", "Telemetry", "input"].includes(type)) {
        clone.textContent = original.textContent;
    }

    // 関数系の再帰複製
    if (["calc_func", "time_func", "export_func", "control_func", "flow_control"].includes(type)) {
        
        const origSlots = Array.from(original.querySelectorAll('.slot'));
        let cloneSlots = Array.from(clone.querySelectorAll('.slot'));
        
        if ((value === 'switch' || value === 'sequence') && origSlots.length > cloneSlots.length) {
            const addBtn = clone.querySelector('.btn-add-case') || clone.querySelector('.btn-add-step');
            
            if (addBtn) {
                while (clone.querySelectorAll('.slot').length < origSlots.length) {
                    addBtn.click();
                }
                cloneSlots = Array.from(clone.querySelectorAll('.slot'));
            }
        }

        origSlots.forEach((oSlot, idx) => {
            Array.from(oSlot.children).forEach(child => {
                if (!child.classList.contains('block')) return;
                
                const childClone = duplicateBlock(child);
                if (childClone) {
                    if (cloneSlots[idx]) {
                        cloneSlots[idx].appendChild(childClone);
                        childClone.style.position = "static";
                    } else {
                        removeBlock(childClone);
                    }
                }
            });
        });
    }
    return clone;
}

function removeBlock(b) {
    if (!b) return;

    // ネストしたブロックの再帰的削除
    b.querySelectorAll('.slot').forEach(s => {
        Array.from(s.children)
            .filter(el => el.classList.contains('block'))
            .forEach(removeBlock);
    });

    const g = blockGroups.get(b); 
    if (g) { 
        g.forEach(x => blockGroups.delete(x)); 
        removeGroupBox(g); 
    } 
    
    b.remove(); 
    if (typeof blocks !== 'undefined') {
        blocks = blocks.filter(x => x !== b); 
    }
}

function clearAllBlocks() {
    if (blocks.length === 0 || !confirm("フィールド上のすべてのブロックを削除しますか？")) return;
    [...blocks].forEach(block => {
        if (block && block.parentNode === field) removeBlock(block);
    });
    blocks = [];
    blockGroups.clear();
    document.querySelectorAll('.group-box').forEach(el => el.remove());
}

/* ================= イベントハンドラ ================= */

window.addEventListener('keydown', e => {
    // --- ドラッグ中の操作 ---
    if (dragInfo) {
        if (e.key === 'Delete' || e.key === 'Backspace') {
            e.preventDefault();
            const groupToDelete = [...dragInfo.group];
            dragInfo = null;
            
            if (typeof dropToTrash === 'function') dropToTrash(groupToDelete);
            else groupToDelete.forEach(removeBlock);

            if (typeof hideInsertIndicator === 'function') hideInsertIndicator();
            return;
        }

        if (e.key === 'c' || e.key === 'C') {
            e.preventDefault();
            const oldGroup = dragInfo.group;
            
            oldGroup.forEach(b => b.classList.remove("dragging"));

            const offsetDist = 5;
            const newGroup = oldGroup.map(ob => {
                const nx = ob.offsetLeft + offsetDist;
                const ny = ob.offsetTop + offsetDist;
                return duplicateBlock(ob, nx, ny);
            });
            
            newGroup.forEach(nb => nb.classList.add("dragging"));
            
            dragInfo.group = newGroup;
            dragInfo.offsets = newGroup.map(nb => ({
                block: nb,
                offsetX: lastMousePos.x - nb.offsetLeft,
                offsetY: lastMousePos.y - nb.offsetTop
            }));
            
            if (dragInfo.activeBoxData && dragInfo.activeBoxData.el) {
                dragInfo.activeBoxData.el.style.pointerEvents = '';
            }

            if (newGroup.length > 1) {
                newGroup.forEach(nb => blockGroups.set(nb, newGroup));
                drawGroupBox(newGroup);

                const newBox = groupBoxes.get(newGroup);
                if (newBox) {
                    newBox.style.pointerEvents = 'none';
                    dragInfo.activeBoxData = {
                        el: newBox,
                        offsetX: lastMousePos.x - newBox.offsetLeft,
                        offsetY: lastMousePos.y - newBox.offsetTop
                    };
                }
            } else {
                dragInfo.activeBoxData = null;
            }

            updateAllGroupBoxes();
        }
    } 
    // --- ドラッグしていない時の操作 ---
    else {
        // 全消去 (Shift + Delete)
        if (e.key === 'Delete' && e.shiftKey) {
            e.preventDefault();
            clearAllBlocks();
        }

        // ★追加: 視点リセット (Homeキー)
        if (e.key === 'Home') {
            e.preventDefault();
            resetFieldPosition();
        }
    }
});

/**
 * 視点移動をリセットして初期位置(0,0)に戻す関数
 */
function resetFieldPosition() {
    // すでに初期位置なら何もしない
    if (fieldBgX === 0 && fieldBgY === 0) return;

    // 現在のズレ分を逆算して戻す量
    const reverseX = -fieldBgX;
    const reverseY = -fieldBgY;

    // 1. 背景変数のリセット
    fieldBgX = 0;
    fieldBgY = 0;
    field.style.backgroundPosition = '0px 0px';

    // 2. 全ブロックの位置を戻す
    if (typeof blocks !== 'undefined') {
        blocks.forEach(block => {
            const currentLeft = parseFloat(block.style.left) || 0;
            const currentTop = parseFloat(block.style.top) || 0;
            block.style.left = `${currentLeft + reverseX}px`;
            block.style.top = `${currentTop + reverseY}px`;
        });
    }

    // 3. グループ枠の位置を戻す
    if (typeof groupBoxes !== 'undefined') {
        groupBoxes.forEach(boxEl => {
            const currentLeft = parseFloat(boxEl.style.left) || 0;
            const currentTop = parseFloat(boxEl.style.top) || 0;
            boxEl.style.left = `${currentLeft + reverseX}px`;
            boxEl.style.top = `${currentTop + reverseY}px`;
        });
    }
}

/* ================= グループボックス描画 ================= */

function drawGroupBox(group){
    removeGroupBox(group);
    if(!group || group.length <= 1) return;

    const box = dom.create('div', 'group-box');
    field.appendChild(box);
    groupBoxes.set(group, box);
    updateGroupBox(group);
}

function updateGroupBox(group) {
    if (!group || group.length <= 1) { 
        removeGroupBox(group); 
        return; 
    }

    const validBlocks = group.filter(b => b.parentNode === field);
    if (validBlocks.length <= 1) {
        removeGroupBox(group);
        return;
    }

    const box = groupBoxes.get(group);
    if(!box) return;
    
    // ソートして位置計算
    const sorted = validBlocks.sort((a, b) => a.offsetLeft - b.offsetLeft); 
    
    let curL = sorted[0].offsetLeft;
    const top = Math.min(...sorted.map(b => b.offsetTop));
    
    // 簡易横並び配置
    sorted.forEach((b) => {
        b.style.left = `${curL}px`; 
        b.style.top = `${top}px`;
        curL += b.offsetWidth + 5;
    });
    
    const totalW = curL - 5 - sorted[0].offsetLeft;
    const maxH = Math.max(...sorted.map(b => b.offsetHeight));
    
    Object.assign(box.style, { 
        left: `${sorted[0].offsetLeft - 5}px`, 
        top: `${top - 5}px`, 
        width: `${totalW + 10}px`, 
        height: `${maxH + 10}px`, 
        display: 'block' 
    });
}

function removeGroupBox(g){ 
    const box = groupBoxes.get(g); 
    if(box){ 
        box.remove(); 
        groupBoxes.delete(g); 
    } 
}

function updateAllGroupBoxes(){ 
    const seen = new Set(); 
    blockGroups.forEach(g => { 
        if(!seen.has(g)){ 
            updateGroupBox(g); 
            seen.add(g); 
        }
    }); 
}

function updateParentGroupsRecursive(block) {
    let current = block;
    while (current) {
        const pg = blockGroups.get(current);
        if (pg) updateGroupBox(pg);
        
        const parentSlot = current.closest('.slot');
        current = parentSlot ? parentSlot.closest('.block') : null;
    }
}